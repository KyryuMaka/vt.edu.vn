import bannerTB from "../images/BannerThongBao.jpg"
import { FaAngleRight } from "react-icons/fa6";

function TSNotification(){
    
    return (
        <>
        <div className="bg-[#214287] pb-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 container mx-auto">
                <div>
                    <h1 className="text-white text-3xl font-bold pt-4 text-center">THÔNG BÁO TUYỂN SINH</h1>
                    <div className="text-xs font-medium text-white py-10">
                        <div className="mx-4 mb-6 grid grid-cols-1 lg:grid-cols-2">
                            <div className="h-20 hidden lg:block"></div>
                            <div>
                                <a href=" " className="flex items-center text-base font-bold py-2 border-b border-gray-600">
                                    <FaAngleRight />&nbsp;Lịch sử phát triển
                                </a>
                            </div>
                        </div>
                        <div className="mx-4 mb-6 grid grid-cols-1 lg:grid-cols-2">
                            <div className="h-20 hidden lg:block"></div>
                            <div>
                                <a href=" " className="flex items-center text-base font-bold py-2 border-b border-gray-600">
                                    <FaAngleRight />&nbsp;Lịch sử phát triển
                                </a>
                            </div>
                        </div>
                        <div className="mx-4 mb-6 grid grid-cols-1 lg:grid-cols-2">
                            <div className="h-20 hidden lg:block"></div>
                            <div>
                                <a href=" " className="flex items-center text-base font-bold py-2 border-b border-gray-600">
                                    <FaAngleRight />&nbsp;Lịch sử phát triển
                                </a>
                            </div>
                        </div>
                        <div className="mx-4 mb-6 grid grid-cols-1 lg:grid-cols-2">
                            <div className="h-20 hidden lg:block"></div>
                            <div>
                                <a href=" " className="flex items-center text-base font-bold py-2 border-b border-gray-600">
                                    <FaAngleRight />&nbsp;Lịch sử phát triển
                                </a>
                            </div>
                        </div>
                    </div>
                    <div className="flex justify-center">
                        <a href=" " className="flex items-center bg-[#49a942] text-white font-bold py-2 px-4 rounded-md">XEM THÊM <FaAngleRight /></a>
                    </div>
                </div>
                <div className="flex items-center my-10">
                    <img src={bannerTB} alt="" />
                </div>
            </div>
        </div>
        </>
    )
}

export default TSNotification;