import { useEffect, useState } from "react";
import dllhIcon from "../images/dllh.png";

function href3(e){
    e.preventDefault();
    window.location.href = "#dangky";
}

function TabCTDT(){
    const [windowWidth, setWindowWidth] = useState(0);
    useEffect(() => {
        // Access the window object in the useEffect hook
        setWindowWidth(window.innerWidth);
        const handleResize = () => {
            setWindowWidth(window.innerWidth);
        };
        window.addEventListener('resize', handleResize);
        return () => {
            window.removeEventListener('resize', handleResize);
        };
    }, []);

    function click(e){
        //Thay đổi content
        var id1 = e.target.id; //Lấy id của button đang chọn
        var content = "";
        switch(id1){
            case "tc": 
                content = ` <div class="text-center my-10">
                                <img src=${dllhIcon} alt="" class="w-1/3 mx-auto"/>
                                <p class="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                            </div>`; 
                break;
            case "lt":
                content = ` <div class="text-center my-10">
                                <img src=${dllhIcon} alt="" class="w-1/3 mx-auto"/>
                                <p class="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                            </div>`; 
                break;
            case "vb2": 
                content = ` <div class="text-center my-10">
                                <img src=${dllhIcon} alt="" class="w-1/3 mx-auto"/>
                                <p class="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                            </div>`;  
                break;
            case "dhtx": 
                content = ` <div class="text-center my-10">
                                <img src=${dllhIcon} alt="" class="w-1/3 mx-auto"/>
                                <p class="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                            </div>`;
                break;
            case "sc":
                content = ` <div class="text-center my-10">
                                <img src=${dllhIcon} alt="" class="w-1/3 mx-auto"/>
                                <p class="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                            </div>`;
                break;
            default: content = `    <div class="text-center my-10">
                                        <img src=${dllhIcon} alt="" class="w-1/3 mx-auto"/>
                                        <p class="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                                    </div>`;
        }
        document.getElementById("content").innerHTML=content;

        //toogle class active
        var x = document.getElementById("tabnav").querySelectorAll(".active");
        x[0].classList.remove("active")
        document.getElementById(id1).classList.add("active");
    }

    return (
        <>
        <div className="py-3">
            <h1 className="text-center font-bold text-[#555] my-5 text-4xl">Chương trình đào tạo</h1>
            <div id="tabnav" className="flex flex-wrap items-center justify-center">
                <button id="tc" onClick={click} className="rounded-full bg-[#eeeeee] hover:bg-[#49A942] hover:text-white p-3 m-2 text-[#777] text-xs font-bold active">
                    TRUNG CẤP
                </button>
                <button id="lt" onClick={click} className="rounded-full bg-[#eeeeee] hover:bg-[#49A942] hover:text-white p-3 m-2 text-[#777] text-xs font-bold">
                    LIÊN THÔNG
                </button>
                <button id="vb2" onClick={click} className="rounded-full bg-[#eeeeee] hover:bg-[#49A942] hover:text-white p-3 m-2 text-[#777] text-xs font-bold">
                    VĂN BẰNG 2
                </button>
                <button id="dhtx" onClick={click} className="rounded-full bg-[#eeeeee] hover:bg-[#49A942] hover:text-white p-3 m-2 text-[#777] text-xs font-bold">
                    ĐẠI HỌC HỆ TỪ XA
                </button>
                <button id="sc" onClick={click} className="rounded-full bg-[#eeeeee] hover:bg-[#49A942] hover:text-white p-3 m-2 text-[#777] text-xs font-bold">
                    SƠ CẤP
                </button>
            </div>
            <div id="content" className="grid grid-cols-2 lg:grid-cols-6 justify-items-center">
                <div className="text-center my-10">
                    <img src={dllhIcon} alt="" className="w-1/3 mx-auto"/>
                    <p className="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                </div>
                <div className="text-center my-10">
                    <img src={dllhIcon} alt="" className="w-1/3 mx-auto"/>
                    <p className="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                </div>
                <div className="text-center my-10">
                    <img src={dllhIcon} alt="" className="w-1/3 mx-auto"/>
                    <p className="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                </div>
                <div className="text-center my-10">
                    <img src={dllhIcon} alt="" className="w-1/3 mx-auto"/>
                    <p className="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                </div>
                <div className="text-center my-10">
                    <img src={dllhIcon} alt="" className="w-1/3 mx-auto"/>
                    <p className="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                </div>
                <div className="text-center my-10">
                    <img src={dllhIcon} alt="" className="w-1/3 mx-auto"/>
                    <p className="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                </div>
                <div className="text-center my-10">
                    <img src={dllhIcon} alt="" className="w-1/3 mx-auto"/>
                    <p className="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                </div>
                <div className="text-center my-10">
                    <img src={dllhIcon} alt="" className="w-1/3 mx-auto"/>
                    <p className="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                </div>
                <div className="text-center my-10">
                    <img src={dllhIcon} alt="" className="w-1/3 mx-auto"/>
                    <p className="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                </div>
                <div className="text-center my-10">
                    <img src={dllhIcon} alt="" className="w-1/3 mx-auto"/>
                    <p className="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                </div>
                <div className="text-center my-10">
                    <img src={dllhIcon} alt="" className="w-1/3 mx-auto"/>
                    <p className="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                </div>
                <div className="text-center my-10">
                    <img src={dllhIcon} alt="" className="w-1/3 mx-auto"/>
                    <p className="text-[#555] font-bold pt-1">Du lịch lữ hành</p>
                </div>
            </div>
        </div>
        </>
    )
}

export default TabCTDT;