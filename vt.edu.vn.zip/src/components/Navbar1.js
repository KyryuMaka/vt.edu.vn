import logo from "../images/logo.png";
import { FaPhone, FaFacebook, FaEnvelope, FaYoutube, FaBars, FaChevronDown } from "react-icons/fa6";
import { FaHome } from "react-icons/fa";

function toggleDrawer(e){
    e.preventDefault();
    var drawer = document.getElementById("drawer");
    var drawer1 = document.getElementById("drawer1");
    drawer.classList.toggle("-translate-x-full");
    drawer1.classList.toggle("-translate-x-full");
}

function Navbar1(){
    return(
        <>
        <nav className="bg-white border-gray-200 py-2">
            <div className="container mx-auto grid grid-cols-3 lg:grid-cols-2">
                <div className="justify-self-start grid content-center ml-3 lg:hidden">
                    <button className="border p-3" onClick={toggleDrawer}><FaBars /></button>
                </div>
                <a href="https://vt.edu.vn/" className="justify-self-center lg:justify-self-start flex">
                    <img src={logo} className="h-20 lg:h-28" alt="Flowbite Logo" />
                    <span className="hidden lg:block self-center text-2xl font-semibold whitespace-nowrap ml-3">TRƯỜNG TRUNG CẤP<br/>VẠN TƯỜNG</span>
                </a>
                <div className="grid content-center justify-self-end">
                    <div className="p-3 hidden lg:flex items-center">
                        <a href="tel:0964 380 333" className="flex items-center text-2xl font-semibold"><FaPhone /><span className="mx-3">0964 380 333</span></a>
                        <a href=" " className="text-4xl font-semibold mx-1 text-blue-600"><FaFacebook /></a>
                        <a href=" " className="text-4xl font-semibold mx-1"><FaEnvelope /></a>
                        <a href=" " className="text-5xl font-semibold mx-1 text-red-600"><FaYoutube /></a>
                    </div>
                </div>
            </div>
        </nav>
        <div id="drawer" className="fixed top-0 left-0 z-40 h-screen w-screen overflow-y-auto transition-transform duration-0 -translate-x-full bg-[#777]/75">
            <div id="drawer1" className="fixed top-0 left-0 z-40 h-screen p-4 overflow-y-auto transition-transform duration-300 -translate-x-full bg-white w-64" tabIndex="-1">
                {/* <h5 className="inline-flex items-center mb-4 text-base font-semibold text-gray-500 dark:text-gray-400">
                    <a href=" " className="text-xl"><FaHome /></a>
                </h5> */}
                <div class="overflow-y-auto">
                    <ul class="space-y-2 font-medium">
                        <li>
                            <a href=" " className="flex items-center p-2 text-gray-900 rounded-lg text-xl hover:bg-gray-100">
                                <span class="flex-1 text-left whitespace-nowrap"><FaHome /></span>
                                {/* <span class="inline-flex items-center justify-center w-3 h-3 p-3 ml-3 font-medium">3</span> */}
                            </a>
                        </li>
                        <li>
                            <button type="button" class="w-full flex items-center p-2 text-gray-900 rounded-lg hover:bg-gray-100">
                                <p class="flex-1 text-left whitespace-nowrap">GIỚI THIẸU</p>
                                <FaChevronDown />
                            </button>
                            <ul id="dropdown-example" class="hidden py-2 space-y-2">
                                <li>
                                    <a href=" " class="flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:hover:bg-gray-700">Products</a>
                                </li>
                                <li>
                                    <a href=" " class="flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:hover:bg-gray-700">Billing</a>
                                </li>
                                <li>
                                    <a href=" " class="flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:hover:bg-gray-700">Invoice</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <button type="button" class="w-full flex items-center p-2 text-gray-900 rounded-lg hover:bg-gray-100">
                                <p class="flex-1 text-left whitespace-nowrap">TUYỂN SINH</p>
                                <FaChevronDown />
                            </button>
                            <ul id="dropdown-example" class="hidden py-2 space-y-2">
                                <li>
                                    <a href=" " class="flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:hover:bg-gray-700">Products</a>
                                </li>
                                <li>
                                    <a href=" " class="flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:hover:bg-gray-700">Billing</a>
                                </li>
                                <li>
                                    <a href=" " class="flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:hover:bg-gray-700">Invoice</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <button type="button" class="w-full flex items-center p-2 text-gray-900 rounded-lg hover:bg-gray-100">
                                <p class="flex-1 text-left whitespace-nowrap">CÁC PHÒNG, BAN</p>
                                <FaChevronDown />
                            </button>
                            <ul id="dropdown-example" class="hidden py-2 space-y-2">
                                <li>
                                    <a href=" " class="flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:hover:bg-gray-700">Products</a>
                                </li>
                                <li>
                                    <a href=" " class="flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:hover:bg-gray-700">Billing</a>
                                </li>
                                <li>
                                    <a href=" " class="flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:hover:bg-gray-700">Invoice</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <button type="button" class="w-full flex items-center p-2 text-gray-900 rounded-lg hover:bg-gray-100">
                                <p class="flex-1 text-left whitespace-nowrap">SINH VIÊN</p>
                                <FaChevronDown />
                            </button>
                            <ul id="dropdown-example" class="hidden py-2 space-y-2">
                                <li>
                                    <a href=" " class="flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:hover:bg-gray-700">Products</a>
                                </li>
                                <li>
                                    <a href=" " class="flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:hover:bg-gray-700">Billing</a>
                                </li>
                                <li>
                                    <a href=" " class="flex items-center w-full p-2 text-gray-900 transition duration-75 rounded-lg pl-11 group hover:bg-gray-100 dark:hover:bg-gray-700">Invoice</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href=" " type="button" class="w-full flex items-center p-2 text-gray-900 rounded-lg hover:bg-gray-100">
                                <p class="flex-1 text-left whitespace-nowrap">TIN TỨC - HOẠT ĐỘNG</p>
                            </a>
                        </li>
                        <li>
                            <a href=" " type="button" class="w-full flex items-center p-2 text-gray-900 rounded-lg hover:bg-gray-100">
                                <p class="flex-1 text-left whitespace-nowrap">QUY ĐỊNH - HƯỚNG DẪN</p>
                            </a>
                        </li>
                        <li>
                            <a href=" " type="button" class="w-full flex items-center p-2 text-gray-900 rounded-lg hover:bg-gray-100">
                                <p class="flex-1 text-left whitespace-nowrap">ĐÀO TẠO TRỰC TUYẾN</p>
                            </a>
                        </li>
                        <li>
                            <a href=" " type="button" class="w-full flex items-center p-2 text-gray-900 rounded-lg hover:bg-gray-100">
                                <p class="flex-1 text-left whitespace-nowrap">XÉT TUYỂN ONLINE</p>
                            </a>
                        </li>
                        <li>
                            <a href=" " type="button" class="w-full flex items-center p-2 text-gray-900 rounded-lg hover:bg-gray-100">
                                <p class="flex-1 text-left whitespace-nowrap">LIÊN HỆ</p>
                            </a>
                        </li>
                        <li>
                            <div className="p-3 flex items-center">
                                <a href=" " className="text-4xl font-semibold mx-1 text-blue-600"><FaFacebook /></a>
                                <a href=" " className="text-4xl font-semibold mx-1"><FaEnvelope /></a>
                                <a href=" " className="text-5xl font-semibold mx-1 text-red-600"><FaYoutube /></a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <button type="button" onClick={toggleDrawer} className="text-white bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 absolute top-2.5 right-2.5 inline-flex items-center justify-center dark:hover:bg-gray-600 dark:hover:text-white" >
                <svg className="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                    <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                </svg>
                <span className="sr-only">Close menu</span>
            </button>
        </div>
        <nav className="hidden lg:bg-[#234287] lg:block">
            <div className="px-3 py-3 mx-auto container">
                <div className="flex items-center">
                    <ul className="flex flex-row font-medium mt-0 text-xs items-center">
                        <li className="flex text-white border-r pr-3">
                            <a href=" " className="text-xl"><FaHome /></a>
                        </li>
                        <li className="flex text-white border-r px-3 lg:inline-block lg:relative lg:hover:block">
                            <button type="button" class="flex items-center">
                                <p class="me-2">GIỚI THIẸU</p>
                                <FaChevronDown />
                            </button>
                            <div id="dropdownNavbar" class="lg:hidden lg:absolute lg:bg-white lg:z-10 lg:hover:block">
                                <ul class="py-2 text-sm text-gray-700 dark:text-gray-400" aria-labelledby="dropdownLargeButton">
                                    <li>
                                        <a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Dashboard</a>
                                    </li>
                                    <li>
                                        <a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Settings</a>
                                    </li>
                                    <li>
                                        <a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Earnings</a>
                                    </li>
                                </ul>
                                <div class="py-1">
                                    <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-400 dark:hover:text-white">Sign out</a>
                                </div>
                            </div>
                        </li>
                        <li className="flex text-white border-r px-3">
                            <a href=" " className="me-2">TUYỂN SINH</a><FaChevronDown />
                        </li>
                        <li className="flex text-white border-r px-3">
                            <a href=" " className="me-2">CÁC PHÒNG, BAN</a><FaChevronDown />
                        </li>
                        <li className="flex text-white border-r px-3">
                            <a href=" " className="me-2">SINH VIÊN</a><FaChevronDown />
                        </li>
                        <li className="flex text-white border-r px-3">
                            <a href=" ">TIN TỨC - HOẠT ĐỘNG</a>
                        </li>
                        <li className="flex text-white border-r px-3">
                            <a href=" ">QUY ĐỊNH - HƯỚNG DẪN</a>
                        </li>
                        <li className="flex text-white border-r px-3">
                            <a href=" ">ĐÀO TẠO TRỰC TUYỂN</a>
                        </li>
                        <li className="flex text-white border-r px-3">
                            <a href=" ">XÉT TUYỂN ONLINE</a>
                        </li>
                        <li className="flex text-white px-3">
                            <a href=" ">LIÊN HỆ</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        </>
    )
}

export default Navbar1