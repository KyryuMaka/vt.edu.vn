import { FaAngleRight } from "react-icons/fa6";

function RecentNews(){
    
    return (
        <>
            <div className="bg-[#2E8927]">
                <p className="text-white text-lg font-medium ps-4 pt-4">TIN MỚI NHẤT</p>
                <ul className="text-xs font-medium text-white">
                    <li className="w-96 mx-4 py-2 border-b border-gray-600">
                        <a href=" " className="flex">
                            <FaAngleRight />&nbsp;Lịch sử phát triển
                        </a>
                    </li>
                    <li className="w-96 mx-4 py-2 border-b border-gray-600">
                        <a href=" " className="flex">
                            <FaAngleRight />&nbsp;Sứ mạng, tầm nhìn
                        </a>
                    </li>
                    <li className="w-96 mx-4 py-2 border-b border-gray-600">
                        <a href=" " className="flex">
                            <FaAngleRight />&nbsp;Thông điệp của Hiệu trưởng
                        </a>
                    </li>
                    <li className="w-96 mx-4 py-2">
                        <a href=" " className="flex">
                            <FaAngleRight />&nbsp;Sơ đồ đến trường
                        </a>
                    </li>
                </ul>
            </div>
        </>
    )
}

export default RecentNews;